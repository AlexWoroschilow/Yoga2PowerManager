__author__ = 'sensey'

class Switcher():
    def __init__(self):
        print('sf')

    def powersave(self):
        print('powersave')

    def perfomance(self):
        print('perfomance')