__author__ = 'sensey'
__all__ = [
           "Plugins",
           "indicator",
           ]